import React from "react";
import Header from "./Header";
import { connect } from "react-redux";
import isEmpty from "lodash/isEmpty";
function AdminDashboard(props) {
  return (
    <div>
      <Header {...props} />
      {!isEmpty(props.user) && (
        <div>
          <h1>Total Employees - {props.user.length}</h1>
          {props.user.map((user) => {
            return <h3 key={user._id}>{user.username}</h3>;
          })}
        </div>
      )}
    </div>
  );
}
const mapStateToProps = (state) => {
  return {
    user: state.user,
  };
};
export default connect(mapStateToProps)(AdminDashboard);
