export const increment = () => {
  return {
    type: "INCREMENT",
  };
};
